A LITTLE PLACE CALLED US — PERSONALIZED FOR NABILKU

Personalized details:
- Creator: lovelies
- Partner: arthanabil, affectionately called nabilku
- Personal detail: active, energetic, very talkative; the website celebrates that while reassuring him that he is loved on quiet/tired days too.
- Music: "us, now" by Ohyul (audio file must be added by you).

Files:
- index.html: website structure and personalized messages
- style.css: blush-pink / cream coquette design
- script.js: flower discoveries, personalized quiz, letters, hearts and navigation

Preview:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Upload index.html, style.css and script.js to the root of your GitHub repository.
4. Enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).

Add the song:
1. Add an audio file you have the right to use, named exactly song.mp3, into the same folder as index.html.
2. Upload song.mp3 to the root of your GitHub repository too.
3. The top-right "our song" button plays it after the visitor clicks it.
The project does not include the copyrighted song itself.

Customize:
- Main welcome and ending messages are in index.html.
- Flower messages, quiz questions, and letters are in script.js.
- Colors and layout are in style.css.

The website is a front-end gift. It does not collect or send personal data.

const pages = ["welcome", "garden", "quiz", "letters", "ending"];
const discoveredFlowers = new Set();
let questionIndex = 0;
let heartCount = 0;

const quizQuestions = [
  {
    question: "What is one thing I adore about you?",
    answers: ["How you can talk about anything and everything", "How you never have any stories", "How you pretend to be someone else"],
    correct: 0,
    note: "Yes, nabilku. Your talkative, lively self is one of the things that makes you so wonderfully you. ♡"
  },
  {
    question: "What do I want you to remember on a difficult day?",
    answers: ["You have to make everyone smile", "You can be quiet and still be loved", "You must always have everything figured out"],
    correct: 1,
    note: "You never have to be energetic or have the perfect words for me to love you, arthanabil."
  },
  {
    question: "What would I choose, in every little universe?",
    answers: ["A perfect day with no problems", "A thousand roses and no conversations", "Another chance to find you and choose you"],
    correct: 2,
    note: "Always you. Your stories, your heart, your whole wonderfully human self. I'd choose you again. ♡"
  }
];

const letters = {
  miss: {
    title: "When you miss me",
    body: "Hi, nabilku. If I could, I'd be right beside you right now, listening to whatever story is on your mind and stealing a little time just for us. Until I can do that, let this letter be a tiny hug from me. Even when we're doing different things, you're still someone I want to tell things to. I hope you feel close to me, even from wherever you are. I'm sending you all the affection I can't fit into this little screen. — lovelies ♡"
  },
  hard: {
    title: "When today feels hard",
    body: "My love, take a slow breath. You don't have to be the energetic one every single day. You don't have to fill every silence, make every conversation fun, or pretend you're okay when you're not. You can tell me what's wrong, sit quietly, or take your time finding the words. I'm proud of you for making it through today, even if it felt messy. You deserve care on your low days just as much as on your brightest ones. — lovelies ♡"
  },
  random: {
    title: "Just because I love you",
    body: "This letter doesn't need a special occasion. I just wanted to remind you that I adore the way your mind is always moving, how you have so much to say, and how your little stories can make an ordinary moment feel alive. I love hearing from you, and I love the person behind all those words, too. Thank you for letting me know you, arthanabil. Out of all the little things this world could have given me, I'm really glad one of them was you. — lovelies ♡"
  }
};

function showPage(id) {
  pages.forEach(page => document.getElementById(page).classList.toggle("active", page === id));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function openEnvelope() {
  document.getElementById("envelope").classList.add("open");
  setTimeout(() => showPage("garden"), 650);
}

document.getElementById("envelope").addEventListener("click", openEnvelope);
document.getElementById("envelope").addEventListener("keydown", e => {
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openEnvelope(); }
});
document.getElementById("enterBtn").addEventListener("click", openEnvelope);

document.querySelectorAll(".flower").forEach((flower, index) => {
  flower.addEventListener("click", () => {
    const message = flower.dataset.message;
    document.getElementById("flowerMessage").innerHTML = `<span class="card-flower">✿</span><p>${message}</p>`;
    flower.classList.add("found");
    discoveredFlowers.add(index);
    document.getElementById("flowerProgress").textContent = `${discoveredFlowers.size} of 5 flowers discovered`;
    if (discoveredFlowers.size === 5) document.getElementById("toQuiz").disabled = false;
  });
});

function renderQuestion() {
  const q = quizQuestions[questionIndex];
  document.getElementById("questionCount").textContent = `QUESTION ${questionIndex + 1} / ${quizQuestions.length}`;
  document.getElementById("questionText").textContent = q.question;
  document.getElementById("quizFeedback").textContent = "";
  document.getElementById("nextQuestion").disabled = true;
  document.getElementById("nextQuestion").textContent = questionIndex === quizQuestions.length - 1 ? "open your letters ♡" : "next little question →";
  const answers = document.getElementById("answers");
  answers.innerHTML = "";
  q.answers.forEach((answer, i) => {
    const button = document.createElement("button");
    button.className = "answer-btn";
    button.textContent = answer;
    button.addEventListener("click", () => {
      [...answers.children].forEach(b => { b.classList.remove("selected"); b.disabled = true; });
      button.classList.add("selected");
      document.getElementById("quizFeedback").textContent = i === q.correct ? q.note : "A sweet answer, too. But the real answer is that I love getting to know every part of you. ♡";
      document.getElementById("nextQuestion").disabled = false;
    });
    answers.appendChild(button);
  });
}

document.getElementById("toQuiz").addEventListener("click", () => { renderQuestion(); showPage("quiz"); });
document.getElementById("nextQuestion").addEventListener("click", () => {
  questionIndex++;
  if (questionIndex >= quizQuestions.length) showPage("letters");
  else renderQuestion();
});
document.getElementById("skipQuiz").addEventListener("click", () => showPage("letters"));

document.querySelectorAll(".letter-tile").forEach(tile => {
  tile.addEventListener("click", () => {
    const letter = letters[tile.dataset.letter];
    document.getElementById("letterTitle").textContent = letter.title;
    document.getElementById("letterBody").textContent = letter.body;
    document.getElementById("letterModal").hidden = false;
  });
});
document.getElementById("closeModal").addEventListener("click", () => document.getElementById("letterModal").hidden = true);
document.getElementById("letterModal").addEventListener("click", e => {
  if (e.target.id === "letterModal") e.currentTarget.hidden = true;
});
document.getElementById("toEnding").addEventListener("click", () => showPage("ending"));

document.getElementById("heartButton").addEventListener("click", e => {
  heartCount++;
  document.getElementById("heartCounter").textContent = `love sent: ${heartCount}`;
  const rect = e.currentTarget.getBoundingClientRect();
  for (let i = 0; i < 7; i++) {
    const heart = document.createElement("span");
    heart.className = "floating-heart";
    heart.textContent = ["♡", "♥", "✿"][i % 3];
    heart.style.left = `${rect.left + rect.width / 2 + (Math.random() * 100 - 50)}px`;
    heart.style.top = `${rect.top}px`;
    heart.style.fontSize = `${16 + Math.random() * 18}px`;
    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 1800);
  }
});
document.getElementById("restartBtn").addEventListener("click", () => {
  discoveredFlowers.clear();
  document.querySelectorAll(".flower").forEach(f => f.classList.remove("found"));
  document.getElementById("flowerProgress").textContent = "0 of 5 flowers discovered";
  document.getElementById("toQuiz").disabled = true;
  questionIndex = 0;
  document.getElementById("envelope").classList.remove("open");
  showPage("welcome");
});
document.querySelectorAll("[data-page]").forEach(link => link.addEventListener("click", e => {
  e.preventDefault();
  showPage(link.dataset.page);
}));

// Decorative falling petals; no external image files needed.
const petalLayer = document.getElementById("petalLayer");
function makePetal() {
  const petal = document.createElement("span");
  petal.className = "petal";
  petal.textContent = Math.random() > .5 ? "✿" : "·";
  petal.style.left = `${Math.random() * 100}%`;
  petal.style.fontSize = `${10 + Math.random() * 12}px`;
  const duration = 8 + Math.random() * 9;
  petal.style.animationDuration = `${duration}s`;
  petalLayer.appendChild(petal);
  setTimeout(() => petal.remove(), duration * 1000);
}
for (let i = 0; i < 12; i++) setTimeout(makePetal, i * 350);
setInterval(makePetal, 1100);

// Music: put your permitted/personal audio file beside index.html, named song.mp3.
// Browsers require a click before playback; autoplay is intentionally not forced.
const music = document.getElementById("bgMusic");
document.getElementById("musicToggle").addEventListener("click", async () => {
  try {
    if (music.paused) {
      await music.play();
      document.getElementById("musicToggle").innerHTML = "♫ <span>playing our song</span>";
    } else {
      music.pause();
      document.getElementById("musicToggle").innerHTML = "♫ <span>our song</span>";
    }
  } catch (err) {
    alert('Add your audio file as "song.mp3" in the same folder as index.html, then try again.');
  }
});
